/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7.models;
import java.sql.Connection;
import java.sql.*;
import java.util.*;
import lab7.utils.Log.Log;

/*
 *
 * @author LSTI-20
 */
public class ComentariosDAO {
    private Connection conexion;
    Log log = Log.getInstance("C:\\Users\\moust\\Desktop\\lab9.txt");

    
    private void abrirConexion()throws SQLException {
        String url = "jdbc:derby://localhost:1527/Comentarios";
        String username = "fcfm";
        String password = "lsti01";
        
        conexion = DriverManager.getConnection(url, username, password);
    }
    private void cerrarConexion ()throws SQLException{
        conexion.close();
        
    }
    
    public void insertar(ComentariosPOJO pojo){  
        try{
            abrirConexion();
            String insert = "insert into COMENTARIOS (NOMBRE, COMENTARIO) values  ('"+pojo.getNombre() + "', '" + pojo.getComentarios() +"')";
            Statement stmt = conexion.createStatement();
//            int filasAfectadas = 
            stmt.executeUpdate(insert);
            cerrarConexion();
//            return filasAfectadas > 0;
            //return true;
        }catch(Exception e){
//            write("Ha ocurrido un error!");
                log.write("EL error es de tipo: " + e);
        }
    }
    public ArrayList<ComentariosPOJO> buscar(ComentariosPOJO pojo){
        
       
        
        try{
            abrirConexion();
            ArrayList<ComentariosPOJO> comentariosList = new ArrayList();
            Statement stmt = conexion.createStatement();
            String select = "select NOMBRE, comentario from COMENTARIOS where NOMBRE = '" + pojo.getNombre() + "' and COMENTARIO like '%" + pojo.getComentarios()+"%'";
            ResultSet mensajes = stmt.executeQuery(select);
            
            while(mensajes.next()){
                ComentariosPOJO pojo1 = new ComentariosPOJO(); 
                pojo1.setNombre(mensajes.getString("NOMBRE"));
                pojo1.setComentarios(mensajes.getString("COMENTARIO"));
                comentariosList.add(pojo1);
            }
            cerrarConexion();
            return comentariosList;
        }catch(Exception e){
            log.write("EL error es de tipo: " + e);
            return null;
        }
    
    }        
}
//"select nombre, comentario from comentario where nombre = '" + dto.getNombre() + "'+ dto.getComentario'""