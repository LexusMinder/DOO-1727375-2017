/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7.controllers;

import lab7.models.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 *
 * @author LSTI-20
 */
public class ComentariosController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
            PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            HttpSession session = request.getSession();
            String action = request.getParameter("action");
            ComentariosPOJO pojo = new ComentariosPOJO(); 
            ComentariosDAO dao = new ComentariosDAO();
            String nombreTxt =   request.getParameter("nombre");
            String comentariosTxt =  request.getParameter("comentarios");
            pojo.setNombre(nombreTxt);
            pojo.setComentarios(comentariosTxt);
            
            if(action.equals("insert")  ){
                
                dao.insertar(pojo);
                response.sendRedirect("buscar.jsp");
            
            }else{
                response.sendRedirect("error.jsp");
            }
            
            if(action.equals("buscar") ){
                
                pojo.setNombre(nombreTxt);
                pojo.setComentarios(comentariosTxt);
                ArrayList<ComentariosPOJO> comentarios = dao.buscar(pojo);
                session.setAttribute("comentarios", comentarios);
                response.sendRedirect("buscar.jsp");
            }else{
                response.sendRedirect("error.jsp");
            }
//            if (nombreTxt == "' or 1 = 1 -- " || comentariosTxt == "' or 1 = 1 --" || nombreTxt.isEmpty() || comentariosTxt.isEmpty()){
//                RequestDispatcher rd = request.getRequestDispatcher("index.html");
//                rd.include(request, response);
//                out.print("<font color='red'><b>Su solicitud no se ha podiodo procesar. Porfavor ingresa caracteres validos y cadenas de palabras</b></font>");
//            }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
